# Moodstream.ai — Générateur d'emails de prospection

Outil interne pour générer des emails de prospection personnalisés grâce à l'IA Claude (Anthropic).

## Stack

- **React + Vite** — interface utilisateur
- **Netlify Functions** — proxy sécurisé vers l'API Claude (la clé API ne s'expose jamais côté navigateur)
- **Claude Opus** — modèle IA pour la rédaction des emails

---

## 🚀 Déploiement pas à pas

### 1. Mettre les fichiers sur GitHub

```bash
# Dans le dossier du projet
git init
git add .
git commit -m "Initial commit — Moodstream email generator"

# Crée un repo sur github.com, puis :
git remote add origin https://github.com/TON_USERNAME/moodstream-prospection.git
git branch -M main
git push -u origin main
```

### 2. Connecter à Netlify

1. Va sur [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
2. Connecte ton compte GitHub et sélectionne le repo `moodstream-prospection`
3. Les paramètres de build sont déjà configurés dans `netlify.toml` :
   - Build command : `npm run build`
   - Publish directory : `dist`
4. Clique **Deploy site**

### 3. Ajouter la clé API Claude

1. Dans Netlify → ton site → **Site configuration** → **Environment variables**
2. Clique **Add a variable** :
   - **Key** : `ANTHROPIC_API_KEY`
   - **Value** : ta clé API depuis [console.anthropic.com](https://console.anthropic.com)
3. **Save** puis **Trigger deploy** pour redéployer avec la clé

---

## 🔒 Sécurité

La clé API Claude n'est **jamais exposée** dans le code source ni dans le navigateur.  
Tous les appels passent par la Netlify Function `/netlify/functions/generate-email.js` côté serveur.

---

## Développement local

```bash
npm install
npm install -g netlify-cli

# Crée un fichier .env à la racine :
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env

# Lance le serveur local avec les fonctions Netlify :
netlify dev
```

L'app sera disponible sur `http://localhost:8888`

---

## Structure du projet

```
moodstream-prospection/
├── netlify/
│   └── functions/
│       └── generate-email.js   ← proxy API Claude (sécurisé)
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx                 ← interface principale
│   └── main.jsx
├── index.html
├── netlify.toml                ← config build + redirections
├── package.json
└── vite.config.js
```
