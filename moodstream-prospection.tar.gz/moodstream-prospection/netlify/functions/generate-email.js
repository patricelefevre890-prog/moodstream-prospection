export const handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "API key not configured" }),
    };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1024,
        system: `Tu es un expert en prospection commerciale B2B pour Moodstream.ai.
Moodstream.ai est une plateforme SaaS de sonorisation intelligente pour les commerces.
Site officiel : https://www.moodstreamai.com
Slogan : "La bonne musique, au bon endroit, au bon moment."

SOLUTION :
- Musiques IA + sélections d'artistes, automatisées selon les horaires
- Prêt en 10 minutes, aucune compétence technique requise
- Programmation horaire complète à la minute près
- Jingles & annonces personnalisées par IA
- 100% légal, libre de droits, certificat de conformité inclus
- Économies jusqu'à -50%/an vs SABAM/SACEM traditionnel, dès 250€/an
- 14 jours d'essai gratuit, sans engagement, sans carte de crédit

STATS SCIENTIFIQUES (Soundtrack Your Brand, FSR Magazine, Luminate Data) :
- +9% de ventes avec une musique adaptée à la marque
- +31,7% de CA dans la mode avec une musique cohérente
- 96% plus susceptibles d'être mémorisés avec une identité musicale
- 79% des visiteurs écoutent vraiment la musique en commerce
- 41% des clients restent plus longtemps et dépensent plus
- 39% des visiteurs reviennent grâce à une bonne musique d'ambiance
- +42% de temps passé avec une musique adaptée

TON : chaleureux, humain, direct. Jamais corporate ou robotique.
FORMAT : toujours commencer par "OBJET: [objet]" puis une ligne vide puis le corps.`,
        messages: [{ role: "user", content: body.prompt }],
      }),
    });

    const data = await response.json();

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(data),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Claude API error", detail: err.message }),
    };
  }
};
